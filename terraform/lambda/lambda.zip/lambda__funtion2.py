def lambda_funtion(event, context):
    print("Event received")
    print(event)
    return{
            "sourceCode":200, 
            "body":"Event received correctly"
    }
